
# Junbo Wang; 400249823; wangj430
# Apr, 4, 2022
# Python 3.8.7
# Final project

import numpy as np
import open3d as o3d
#from math import *

filename = "C:\Project_final\\ToF_laser.xyz"

print("Testing IO for point cloud ...")
pnt = o3d.io.read_point_cloud(filename, format='xyz')
print(pnt)

print(np.asarray(pnt.points))


num_rotation = 4
data_rotation = 64
lines = []

for i in range(num_rotation):
    for j in range(data_rotation-1):
        lines.append([data_rotation*i+j, data_rotation*i+j+1])


for x in range((num_rotation - 1) * data_rotation):
    lines.append([x, 2*data_rotation*(x//data_rotation+1)-x-2])


line_set = o3d.geometry.LineSet(points=o3d.utility.Vector3dVector(np.asarray(pnt.points)), lines=o3d.utility.Vector2iVector(lines))
o3d.visualization.draw_geometries([line_set])


    
