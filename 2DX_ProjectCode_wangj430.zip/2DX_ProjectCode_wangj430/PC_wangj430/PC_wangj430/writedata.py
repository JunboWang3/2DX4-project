
# Junbo Wang; 400249823; wangj430
# Apr, 4, 2022
# Python 3.8.7
# Final project

import serial
#import numpy as numpy
#import open3d as o3d
from math import *


s = serial.Serial("COM5", 115200)
print("Opening: " + s.name)
         
delta = 120
data_rotation = 64
num_rotation = 4
lst = []
i = 0

for i in range(data_rotation * num_rotation):
    str = ''
    while True:
        x = s.read()        
        c = x.decode()      
        if (c != '/'):
            str += c
        else:
            lst.append(int(str))
            print(int(str))
            break

filename = "C:\Project_final\\ToF_laser.xyz"
with open(filename, 'w') as f:
    idx = 0
    for i in lst:
        x = int(idx // data_rotation) * delta
        
        
        if (int(idx // data_rotation) % 2 == 0):
            alpha = 360/data_rotation * pi/180 * (idx+1) 
        else:
            alpha = - (360/data_rotation) * pi/180 * (idx+1) 
        
        y =  - i * sin(alpha)  
        z = i * cos(alpha)     
        
        f.write('{0:.2f} {1:.2f} {2:.2f}\n'.format(x,y,z))
        idx += 1

print("Closing: " + s.name)
s.close()
