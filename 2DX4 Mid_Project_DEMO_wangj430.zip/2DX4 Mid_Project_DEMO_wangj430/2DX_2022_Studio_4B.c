// 2DX4_Knowledge_Thread_3_Session_1
// This program illustrates the use of SysTick in the C language.
// Note the library headers asscoaited are PLL.h and SysTick.h,
// which define functions and variables used in PLL.c and SysTick.c.
// This program uses code directly from your course textbook.

//  Written by Ama Simons
//  January 18, 2020
//  Last Update: January 18, 2020

// Junbo Wang; 400249823; wangj430
// bus speed = 12 MHz
// distance status LED: PF4 (D3)


#include <stdint.h>
#include "tm4c1294ncpdt.h"
#include "PLL.h"
#include "SysTick.h"


void PortM_Init(void){
	//Use PortM pins for output
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R11;				// activate clock for Port N
	while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R11) == 0){};	// allow time for clock to stabilize
	GPIO_PORTM_DIR_R |= 0xFF;        								// make PN0 out (PN0 built-in LED1)
  GPIO_PORTM_AFSEL_R &= ~0xFF;     								// disable alt funct on PN0
  GPIO_PORTM_DEN_R |= 0xFF;        								// enable digital I/O on PN0
																									// configure PN1 as GPIO
  //GPIO_PORTM_PCTL_R = (GPIO_PORTM_PCTL_R&0xFFFFFF0F)+0x00000000;
  GPIO_PORTM_AMSEL_R &= ~0xFF;     								// disable analog functionality on PN0		
	return;
}


//Turns on D3
void PortF4F1_Init(void){
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R5; //activate the clock for Port F
    while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R5) == 0){};//allow time for clock to stabilize
    GPIO_PORTF_DIR_R=0b00010000; // make PF4 output
    GPIO_PORTF_DEN_R=0b00010010;
    GPIO_PORTF_DATA_R = 0b00000000;
    return;
}


void spin(double angle, int direction_cw, int speed){
    int num_of_rotation = (int) angle/360.0 * 512.0;
    if (direction_cw == 1){
				for(int i=0; i<num_of_rotation; i++){
					  GPIO_PORTM_DATA_R = 0b00001001;
            SysTick_Wait10ms(speed);
            GPIO_PORTM_DATA_R = 0b00000011;
            SysTick_Wait10ms(speed);
            GPIO_PORTM_DATA_R = 0b00000110;
            SysTick_Wait10ms(speed);
            GPIO_PORTM_DATA_R = 0b00001100;
            SysTick_Wait10ms(speed);
					
            
            if ((i + 1) % 64 == 0){                        
                GPIO_PORTF_DATA_R |= 0b00010000;
            }
            
            
            if ((i + 1) % 64 == 2){                        
                GPIO_PORTF_DATA_R &= ~0b00010000;
            }
            
		}
    } else{
        for(int i=0; i<num_of_rotation; i++){
					  GPIO_PORTM_DATA_R = 0b00001100;
					  SysTick_Wait10ms(speed);
					  GPIO_PORTM_DATA_R = 0b00000110;
					  SysTick_Wait10ms(speed);
					  GPIO_PORTM_DATA_R = 0b00000011;
					  SysTick_Wait10ms(speed);
					  GPIO_PORTM_DATA_R = 0b00001001;
					  SysTick_Wait10ms(speed);
            
            
            if ((i + 1) % 64 == 0){                      
                GPIO_PORTF_DATA_R |= 0b00010000;
            }
            
						
            if ((i + 1) % 64 == 2){                      
                GPIO_PORTF_DATA_R &= ~0b00010000;
            }
            
        }
    }
    
    SysTick_Wait10ms(1);
    GPIO_PORTF_DATA_R &= ~0b00010000;

}


int main(void){
	PLL_Init();																			// Default Set System Clock to 120MHz
	SysTick_Init();																	// Initialize SysTick configuration
	PortM_Init();                                   // Initialize Port M
  PortF4F1_Init();
    
  int init = 0;
  int pres = 0;
  while (1){
      pres = GPIO_PORTF_DATA_R;
      if (pres != init && (pres & 0b00000010) == 0b00000000){
          spin(360, 1, 1); 
      }
      init = pres;
      SysTick_Wait10ms(1);
  }
    
}


